package ec.edu.espe.FastPay.model;

public class Tienda {

    private String nombre;

    private String direccion;

    private double telefono;

    private String nomd;

    public Tienda() {
    }
}
