/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ec.edu.espe.FastPay.controller;

/**
 *
 * @author Usuario
 */
public class User {
    private int dni;
    private String name;
    private String Last_Name;
    private String direction;
    private String password;
    
    public static void user_verification(){
        
    }
    public static void update_data(){
        
    }
    
}
